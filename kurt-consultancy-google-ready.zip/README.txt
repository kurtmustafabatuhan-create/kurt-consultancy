KURT Danışmanlık web sitesi

Yayın için bu klasörün TAMAMINI GitHub deposunun kök dizinine yükleyin.
index.html ana sayfadır; robots.txt, sitemap.xml, assets ve hizmet klasörleri SEO için gereklidir.

Form, FormSubmit üzerinden kurtmustafabatuhan@gmail.com adresine yönlendirilmiştir.
İlk gerçek gönderimden sonra bu adrese gelen aktivasyon e-postasındaki bağlantıya bir kez tıklanmalıdır.

Mevcut ana adres:
https://kurtmustafabatuhan-create.github.io/kurt-consultancy/

Özel alan adı satın alındıktan sonra:
1. GitHub Pages ayarındaki Custom domain alanına yeni alan adını yazın.
2. Alan adı sağlayıcısında GitHub Pages DNS kayıtlarını oluşturun.
3. Bu klasördeki canonical ve sitemap adreslerini yeni alan adıyla değiştirin.
4. Google Search Console'a alan adını ekleyip doğrulayın.
5. Search Console'a https://ALAN-ADINIZ/sitemap.xml adresini gönderin.

Not: Alan adı seçimi kesinleşmeden CNAME dosyası eklenmemiştir.
